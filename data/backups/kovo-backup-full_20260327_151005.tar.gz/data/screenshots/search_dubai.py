from duckduckgo_search import DDGS
results = list(DDGS().images("Dubai skyline", max_results=5))
for r in results:
    print(r['image'])
